#!/usr/bin/env python3

"""Build script for PERFEC System applicaitons for the Circuit Playground."""

# Copyright 2026
# Tom Hoffman

import argparse
from pathlib import Path
import subprocess
import shutil
import os
import zipfile

DONT_PRECOMPILE = {"boot.py", "code.py", "config.py","make.py"}
DONT_UPDATE = {"make.py"}
PY_EXT = "py"

def is_python_file(filename: str) -> bool:
    return filename.endswith(PY_EXT)

def local_is_more_recent(root_path: Path, remote_path: Path):
    return (os.path.getmtime(root_path) > os.path.getmtime(remote_path))

def generateRemotePath(root_path: Path, filename: str) -> Path:
    if filename in DONT_PRECOMPILE:
        return root_path / filename
    else:
        return root_path / f"{filename[:-len(PY_EXT)]}m{PY_EXT}" 
    

def main():
    """Main entry point with clean linear flow."""
    parser = argparse.ArgumentParser(description="Compile Python files with mpy-cross.")
    parser.add_argument("mpy_cross_path", help="Path to mpy-cross compiler executable.")
    parser.add_argument("remote_root_path", help="Root directory for output files.")
    
    args = parser.parse_args()
    remote_dir = Path(args.remote_root_path)
    mpy_cross_exe = Path(args.mpy_cross_path).resolve()  # Resolve symlinks
    
    if not remote_dir.is_dir():
        raise FileNotFoundError(f"Output root does not exist: {root_path}")
    if not mpy_cross_exe.is_file():
        raise FileNotFoundError(f"Compiler missing: {mpy_cross_exe}")

    print("Scanning directory...")
    for filename in os.listdir("."):  # Only process files in current dir (not subdirs)
        # Skip directories and not .py files
        if not(is_python_file(filename)):
            continue
        local_path = Path(filename)
        print(type(local_path))
        remote_path = generateRemotePath(remote_dir, filename)

        #if remote_path.exists() and local_is_more_recent()




if __name__ == "__main__":
    main()