#!/usr/bin/env python3

"""Build script for PERFEC System applicaitons for the Circuit Playground."""

# Copyright 2026
# Tom Hoffman
# with questionable assistance from Qwen 3.5, running locally.

import argparse
from pathlib import Path
import subprocess
import shutil
import os

DONT_PRECOMPILE = {"boot.py", "code.py", "make.py"}
DONT_UPDATE = {"make.py"}
PY_EXT = "py"

def is_python_file(filename: str) -> bool:
    return filename.endswith(PY_EXT)

def local_is_more_recent(root_path: Path, remote_path: Path):
    return (os.path.getmtime(root_path) > os.path.getmtime(remote_path))


def is_file_to_compile(filename: str, root_path: Path) -> bool:
    """Decide if a file should be processed in the main loop."""
    # Check timestamp logic only when remote exists AND is newer
    if filename in DONT_PRECOMPILE:
        return False
    remote_path = root_path / f"{filename[:-len(PY_EXT)]}m{PY_EXT}"  # Output suffix "m"
    if remote_path.exists() and local_is_more_recent:
        print(f"  ✗ Remote copy up to date. {remote_path}")  
        return False  # Skip: already up-to-date
    return True

def compile_file(filename: str, mpy_cross_exe: Path, root_path: Path) -> None:
    """Process a single file with compilation + fallback copy logic."""
    local = Path(filename)
    remote = root_path / f"{filename[:-len(PY_EXT)]}m{PY_EXT}"  # Output suffix "m"
    print(f"[{filename}] Processing...")
    
    try:
        # Try compiling first (only if compilation is feasible)
        subprocess.run(
            [str(mpy_cross_exe), str(local)],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False  # Never crash on compile errors
        )
        shutil.move(str(remote.name), str(remote))  # Move compiled output to final location
        print(f"  ✓ Compiled & moved: {remote}")
    
    except FileNotFoundError as e:
        # Compilation failed silently or file doesn't exist → fallback copy
        print(f"  ! Compilation failed ({e}), copying directly...")
        shutil.copyfile(str(remote.name), str(remote))
        print(f"  ✗ Fallback copied: {remote}")
    
    except Exception as e:
        # Catch all other errors (e.g., permission issues) → fallback copy
        print(f"  ? Unexpected error ({e}), copying directly...")
        shutil.copyfile(str(remote.name), str(remote))



def main():
    """Main entry point with clean linear flow."""
    parser = argparse.ArgumentParser(description="Compile Python files with mpy-cross.")
    parser.add_argument("mpy_cross_path", help="Path to mpy-cross compiler executable.")
    parser.add_argument("remote_root_path", help="Root directory for output files.")
    
    args = parser.parse_args()
    root_path = Path(args.remote_root_path)
    mpy_cross_exe = Path(args.mpy_cross_path).resolve()  # Resolve symlinks
    
    if not root_path.is_dir():
        raise FileNotFoundError(f"Output root does not exist: {root_path}")
    if not mpy_cross_exe.is_file():
        raise FileNotFoundError(f"Compiler missing: {mpy_cross_exe}")
    
    print("Scanning directory...")
    for filename in os.listdir("."):  # Only process files in current dir (not subdirs)
        # Skip directories and not .py files
        if not(is_python_file(filename)):
            continue
        # Regular files to be compiled.
        if is_file_to_compile(filename, root_path):
            compile_file(filename, mpy_cross_exe, root_path)
        # Files that should not be compiled and not be updated if in place.
        # this could still be refactored some...
        elif filename in DONT_UPDATE:
            print(f"[{filename}] Processing...")
            remote_path = root_path / filename
            if not(remote_path.exists()):
                shutil.copyfile(str(remote_path.name), str(remote_path))
                print(f"  ✓ Moved: {remote_path}")
        else:
            print(f"[{filename}] Processing...")
            remote_path = root_path / filename
            if remote_path.exists() and local_is_more_recent(root_path, remote_path):
                print(f"  ✗ Remote copy up to date. {remote_path}")
            else:
                shutil.copyfile(str(remote_path.name), str(remote_path))
                print(f"  ✓ Moved: {remote_path}")
    print("Processing complete!")


if __name__ == "__main__":
    main()
